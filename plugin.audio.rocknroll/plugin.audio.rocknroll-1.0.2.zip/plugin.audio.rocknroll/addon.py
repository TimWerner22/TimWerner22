import urllib,urllib2,xbmcplugin,xbmcaddon,xbmcgui,xbmc,os,sys,re

plugin_handle = int(sys.argv[1])
xbmcplugin.setContent(plugin_handle, 'audio')

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo("path").decode('utf-8')

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+str(url)+"&mode="+str(mode)+"&name="+str(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addItem(url, infolabels, img):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('audio', infolabels)
    listitem.setProperty('IsPlayable', 'false')
    ok=xbmcplugin.addDirectoryItem(plugin_handle, url, listitem)
    return ok

xbmc.executebuiltin("Container.SetViewMode(300)")
	
def CATEGORIES():
    addDir('Rock n Roll','play1',1,os.path.join(addon_path,'resources','category_image','4.png'))
    addDir('Rockabilly','play2',1,os.path.join(addon_path,'resources','category_image','2.png'))
    addDir('Blues','play3',1,os.path.join(addon_path,'resources','category_image','3.png'))
	
def PLAY1():
    addItem('http://178.32.56.212:9958/',{ 'title': 'ReLive BopStreet'}, os.path.join(addon_path,'resources','play_image','20.png'))
    addItem('http://5.196.64.74:5025/',{ 'title': 'Big-Daddy-O-Radio'}, os.path.join(addon_path,'resources','play_image','21.png'))
    addItem('http://streaming202.radionomy.com:80/ROCKIN-50sRADIO',{ 'title': 'Rocking fiftys RADIO'}, os.path.join(addon_path,'resources','play_image','16.png'))
def PLAY2():
    addItem('http://209.9.238.6:6042/',{ 'title': 'Rockabilly Radio'}, os.path.join(addon_path,'resources','play_image','13.png'))
    addItem('http://192.99.4.210:3574/listen.pls?sid=1',{ 'title': 'ROCKIN626'}, os.path.join(addon_path,'resources','play_image','11.png'))
    addItem('http://37.187.93.104:8368/listen.pls?sid=1',{ 'title': 'Rockabilly Roadhouse'}, os.path.join(addon_path,'resources','play_image','12.png'))
def PLAY3():
    addItem('http://streaming207.radionomy.com:80/ABLUESDREAM-Classic-NewBlues24H',{ 'title': 'ABLUESDREAM-Classic&NewBlues24H'}, os.path.join(addon_path,'resources','play_image','17.png'))
    addItem('http://wgltradio.ilstu.edu:8000/wgltblues.mp3',{ 'title': 'GLT Blues Radio'}, os.path.join(addon_path,'resources','play_image','18.png'))
    addItem('http://199.101.51.168:8004/',{ 'title': 'Blues Connection'}, os.path.join(addon_path,'resources','play_image','19.png'))
	
try:
    category = xbmc.getInfoLabel('ListItem.FileNameAndPath').split('=')[3]
    if category == 'play1':
        PLAY1()
    if category == 'play2':
        PLAY2()
    if category == 'play3':
        PLAY3()
except:
    CATEGORIES()
	
xbmcplugin.endOfDirectory(plugin_handle)

