#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,sys,os

def killxbmc():
    myplatform = platform()
    print 'Platform: ' + str(myplatform)
    if myplatform == 'osx':
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !')
        sys.exit(0)
    elif myplatform == 'linux':
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !')
        sys.exit(0)
    elif myplatform == 'android':
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am kill org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am kill org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am kill org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass
        try: os.system('adb shell am kill org.xbmc')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS","","package:org.xbmc.kodi")')
        sys.exit(0)
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !')
        sys.exit(0)
    else:
        try: os.system('killall AppleTV')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !')
        sys.exit(0)

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    elif xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def kodi_cleaner():
	
    skin = xbmc.getSkinDir()
    skin_addon = xbmcaddon.Addon(id=skin)
    skin_label = skin_addon.getAddonInfo('id').decode("utf-8")

    dp = xbmcgui.DialogProgress()
    dp.create('HSK KODI FRESH START','','')

    save_addon1 ='plugin.program.hsk_fresh_start'
    save_addon2 ='plugin.program.hskwizard'
    save_addon3 = skin_label

    save_addon4 ='Addons26.db'
    save_addon5 ='Addons27.db'
    save_addon6 ='Textures13.db'
    save_addon7 ='commoncache.db'
		
    save_addon8 ='metadata.album.universal'
    save_addon9 ='metadata.artists.universal'
    save_addon10 ='metadata.common.musicbrainz.org'
    save_addon11 ='metadata.common.imdb.com'

    xbmc.executebuiltin('Action(Stop)')
    clear_dir_path = xbmc.translatePath('special://home')

    for pathentry in os.walk(clear_dir_path,False):
        for dir in pathentry[1]:
            path = os.path.join(pathentry[0],dir)
            dp.update(0)
            if not save_addon1 in path and not save_addon2 in path and not save_addon3 in path and not save_addon4 in path and not save_addon5 in path and not save_addon6 in path and not save_addon7 in path and not save_addon8 in path and not save_addon9 in path and not save_addon10 in path and not save_addon11 in path:
                if os.path.islink(path):

                    try:
                        dp.update(50,str(os.path.basename(path)),'','')
                        os.unlink(path)
                    except:
                        pass
                else:
                    try:
                        dp.update(50,str(os.path.basename(path)),'','')
                        os.rmdir(path)
                    except:
                        pass
            dp.update(100)
        for file in pathentry[2]:
            path = os.path.join(pathentry[0],file)
            dp.update(0)
            if not save_addon1 in path and not save_addon2 in path and not save_addon3 in path and not save_addon4 in path and not save_addon5 in path and not save_addon6 in path and not save_addon7 in path and not save_addon8 in path and not save_addon9 in path and not save_addon10 in path and not save_addon11 in path:			
                try:
                    dp.update(50,str(os.path.basename(path)),'','')
                    os.unlink(path)
                except:
                    pass
            dp.update(100)
    dp.close()
	
i = xbmcgui.Dialog().yesno('HSK Kodi Fresh-Start', 'Kodi jetz bereinigen ?' +'\n'+ 'Der [COLOR lime]HSK WIZARD[/COLOR] bleibt von dieser Aktion unangetastet !')
if i > 0:
    kodi_cleaner()
    killxbmc()