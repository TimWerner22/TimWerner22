#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,os,sys
import urllib2,urllib
import re
import base64
import default
import extract
import downloader

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()  

#format in url-txt :      
#name=''
#url='backup.zip url'
#img='jpg url'
#fanart='jpg url'
#description=''
   
def categories(url):
    link = open_url(url).replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description)
        
def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def decode(s):
    return base64.b64decode(s)

def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://','home'))
    lib=os.path.join(path,'kodi_backup.zip')
    try:
       os.remove(lib)
    except:
       pass
    dp.create('HSK WIZARD','Beginne Download !','Bitte warten ...')
    dp.update(0)
    downloader.download(url, lib, dp)
    dp.close()
    xbmc.sleep(1000)
    dp.create('HSK WIZARD','Entpacke Daten !','Bitte warten ...')
    dp.update(0)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    extract.all(lib,addonfolder,dp)
    dp.close()
    xbmc.sleep(1000)
    try:
       os.remove(lib)
    except:
       pass
    dialog.ok('DOWNLOAD KOMPLETT', 'Leider ist der einzige Weg um die neuen Änderungen'+"\n"+'zu bekommen, Kodi zum schließen zu zwingen !'+"\n\n"+'Klicken Sie auf [COLOR red]( OK )[/COLOR] , um Kodi jetzt zu schließen !'+"\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]'+"\n\n"+'Wenn Kodi aus irgendeinem Grund nicht beendet wird,'+"\n"+'versuchen Sie es über den [COLOR red]Taskmanager[/COLOR] zu beenden !'+"\n"+'[COLOR red]Gegebenenfalls starten Sie das Gerät manuell neu ![/COLOR]')
    killxbmc()

def killxbmc():
    i = dialog.yesno('KODI BEENDEN', 'Sie sind dabei Kodi zu schließen !', 'Möchten Sie fortfahren ?', nolabel='NEIN',yeslabel='JA')
    if i == 0:
        return
    elif i == 1:
        pass
    myplatform = platform()
    print 'Platform: ' + str(myplatform)
    if myplatform == 'osx':
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    elif myplatform == 'linux':
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    elif myplatform == 'android':
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am kill org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am kill org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am kill org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass
        try: os.system('adb shell am kill org.xbmc')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_DETAILS_SETTINGS","","package:org.xbmc.kodi")')
        sys.exit(0)
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    else:
        try: os.system('killall AppleTV')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    elif xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
		
def addon():
    addon=xbmcaddon.Addon()
    if not decode('TE9LSTE5Nzk=')==addon.getAddonInfo(decode('YXV0aG9y')):
        return 'false'
    if not decode('cGx1Z2luLnByb2dyYW0uaHNrd2l6YXJk') == addon.getAddonInfo(decode('aWQ=')):
        return 'false'
    if not decode('W0NPTE9SIGxpbWVdSFNLIFdJWkFSRFsvQ09MT1Jd') == addon.getAddonInfo(decode('bmFtZQ==')):
        return 'false'
def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)+'&fanart='+urllib.quote_plus(fanart)+'&description='+urllib.quote_plus(description)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='Video', infoLabels={ 'Title': name, 'Plot': description } )
    liz.setProperty( 'Fanart_Image', fanart )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                             
    return param
	
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
    url=urllib.unquote_plus(params['url'])
except:
    pass
try:
    name=urllib.unquote_plus(params['name'])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params['iconimage'])
except:
    pass
try:        
    mode=int(params['mode'])
except:
    pass
try:        
    fanart=urllib.unquote_plus(params['fanart'])
except:
    pass
try:        
    description=urllib.unquote_plus(params['description'])
except:
    pass
            
if mode==None or url==None or len(url)<1:
    categories('http://hsk.goip.de/hsk-wizard/hsk-wizard.txt')
    categories('http://v36557.1blu.de/files/public-docs/hsk/hsk-wizard.txt')

elif mode==1:
    if addon() == 'false':sys.exit(0)
    wizard(name,url,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmc.executebuiltin('Container.SetViewMode(500)')