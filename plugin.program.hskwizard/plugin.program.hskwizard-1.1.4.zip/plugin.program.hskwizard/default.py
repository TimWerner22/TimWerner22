#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,os,sys
import urllib2,urllib
import re
import time
import base64
import default
import cleaner
import zipper
import extract
import downloader
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
def open_url(url):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36')
        response = urllib2.urlopen(req)
        res=response.read()
        response.close()
        return res
    except Exception, e:
        return None
        xbmcgui.Dialog().ok('ERROR !',str(e))
def categories(url):
    wContent = open_url(url)
    if not wContent == None:
        wContent = str(wContent.replace('\n','').replace('\r',''))
        match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(wContent)
        for name,url,iconimage,fanart,description in match:
            addDir('[COLOR white]'+name+'[/COLOR]',url,1,iconimage,fanart,description)   
def decode(s):
    return base64.b64decode(s)
def remove(zip_file_path):
    try:
       os.remove(zip_file_path)
    except:
       pass
def wizard(name,url,description):
    path = os.path.normpath(xbmc.translatePath('special://home')).decode('utf-8')
    lib=os.path.join(path,'kodi_backup.zip')
    remove(lib)
    dp.create('HSK WIZARD','Beginne Download !','Bitte warten ...')
    dp.update(0)
    downloader.download(url,lib,dp)
    dp.close()
    xbmc.sleep(1000)
    dp.create('HSK WIZARD','Entpacke Daten !','Bitte warten ...')
    dp.update(0)
    extract.extractZip(lib,path,dp)
    dp.close()
    xbmc.sleep(1000)
    remove(lib)
    dialog.ok('PROZESS KOMPLETT', 'Leider ist der einzige Weg um die neuen Änderungen'+"\n"+'zu bekommen, Kodi zum schließen zu zwingen !'+"\n\n"+'Klicken Sie auf [COLOR red]( OK )[/COLOR] , um Kodi jetzt zu schließen !'+"\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]'+"\n\n"+'Wenn Kodi aus irgendeinem Grund nicht beendet wird,'+"\n"+'versuchen Sie es über den [COLOR red]Taskmanager[/COLOR] zu beenden !'+"\n"+'[COLOR red]Gegebenenfalls starten Sie das Gerät manuell neu ![/COLOR]')
    killxbmc()
def load_wizard_backup(zip_path):
    dp.create('HSK WIZARD','Entpacke Backup !','Bitte warten ...')
    dp.update(0)
    extract.extractZip(zip_path,os.path.normpath(xbmc.translatePath('special://home')).decode('utf-8'),dp)
    dp.close()
    xbmc.sleep(1000)
    dialog.ok('PROZESS KOMPLETT', 'Leider ist der einzige Weg um die neuen Änderungen'+"\n"+'zu bekommen, Kodi zum schließen zu zwingen !'+"\n\n"+'Klicken Sie auf [COLOR red]( OK )[/COLOR] , um Kodi jetzt zu schließen !'+"\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]'+"\n\n"+'Wenn Kodi aus irgendeinem Grund nicht beendet wird,'+"\n"+'versuchen Sie es über den [COLOR red]Taskmanager[/COLOR] zu beenden !'+"\n"+'[COLOR red]Gegebenenfalls starten Sie das Gerät manuell neu ![/COLOR]')
    killxbmc()
def save_wizard_backup(zip_save_path):
    dp.create('HSK WIZARD','Sichere Backup !','Bitte warten ...')
    dp.update(0)
    zipper.ZipDir(os.path.normpath(xbmc.translatePath('special://home')).decode('utf-8'),os.path.join(zip_save_path,'kodi_backup_' + time.strftime('%d%m%Y%H%M%S')) + '.zip',dp)
    dp.close()
    xbmc.sleep(1000)
    sys.exit(0)
def fresh_start():
    dp.create('HSK FRESH START','Bereinige Daten','Bitte warten ...')
    dp.update(0)
    cleaner.clean_data(os.path.normpath(xbmc.translatePath('special://home')).decode('utf-8'),dp)
    dp.close()
    xbmc.sleep(1000)
    killxbmc()
def killxbmc():
    i = dialog.yesno('KODI BEENDEN', 'Sie sind dabei Kodi zu schließen !', 'Möchten Sie fortfahren ?',nolabel='NEIN',yeslabel='JA')
    if i < 1:
        sys.exit(0)
    myplatform = platform()
    print 'Platform: ' + str(myplatform)
    if myplatform == 'osx':
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    elif myplatform == 'linux':
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    elif myplatform == 'android':
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am kill org.xbmc.kodi')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
        except: pass
        try: os.system('adb shell am force-stop com.semperpax.spmc16')
        except: pass
        try: os.system('adb shell am kill com.semperpax.spmc16')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.com.semperpax.spmc16());')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_SETTINGS","","")')
        sys.exit(0)
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    else:
        try: os.system('killall AppleTV')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        dialog.ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !'+"\n\n"+'Schließen Sie Kodi über den [COLOR red]Taskmanager[/COLOR] oder'+"\n"+'starten Sie das Gerät manuell neu !'+"\n\n"+'[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        sys.exit(0)
    sys.exit(0)
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    elif xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
def my_addon():
    addon=xbmcaddon.Addon()
    if not decode('TE9LSTE5Nzk=')==addon.getAddonInfo(decode('YXV0aG9y')):
        return 'false'
    if not decode('cGx1Z2luLnByb2dyYW0uaHNrd2l6YXJk') == addon.getAddonInfo(decode('aWQ=')):
        return 'false'
    if not decode('W0NPTE9SIGJsdWVdSFNLLURFIFdJWkFSRFsvQ09MT1Jd') == addon.getAddonInfo(decode('bmFtZQ==')):
        return 'false'
def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)+'&iconimage='+urllib.quote_plus(iconimage)+'&fanart='+urllib.quote_plus(fanart)+'&description='+urllib.quote_plus(description)
    liz=xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo( type='Video',infoLabels={ 'Title':name,'Plot':description } )
    liz.setProperty( 'Fanart_Image',fanart )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                             
    return param
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
try:
    url=urllib.unquote_plus(params['url'])
except:
    pass
try:
    name=urllib.unquote_plus(params['name'])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params['iconimage'])
except:
    pass
try:        
    mode=int(params['mode'])
except:
    pass
try:        
    fanart=urllib.unquote_plus(params['fanart'])
except:
    pass
try:        
    description=urllib.unquote_plus(params['description'])
except:
    pass       
if mode==None and url==None :
    if os.path.exists(os.path.join(addon_path.decode('utf-8'),'server_url_data')):
        f = open(os.path.join(addon_path.decode('utf-8'),'server_url_data'),'r')
        for line in f.readlines():
            categories(line.strip())
    addDir('','',2,os.path.join(addon_path,'setting.jpg'),os.path.join(addon_path,'fanart.jpg'),'')
    addDir('','',3,os.path.join(addon_path,'load_backup.jpg'),os.path.join(addon_path,'fanart.jpg'),'')
    addDir('','',4,os.path.join(addon_path,'save_backup.jpg'),os.path.join(addon_path,'fanart.jpg'),'')
    addDir('','',5,os.path.join(addon_path,'cleaner.jpg'),os.path.join(addon_path,'fanart.jpg'),'')
if mode==1 :
    if my_addon() == 'false':sys.exit(0)
    wizard(name,url,description)
if mode==3:
    if my_addon() == 'false':sys.exit(0)
    zip_path = addon.getSetting('remote_file_path').decode('utf-8')
    if not zip_path == '' and os.path.isfile(zip_path) and os.path.basename(zip_path).endswith('.zip'):
        load_wizard_backup(zip_path)
    else:
        dialog.ok('ACHTUNG !','Addon Settings : Backup Zip Dateipfad ?')
        xbmc.executebuiltin('Addon.OpenSettings('+addon.getAddonInfo('id').decode('utf-8')+')')
        sys.exit(0)
if mode==4:
    if my_addon() == 'false':sys.exit(0)
    zip_save_path = addon.getSetting('remote_folder_path').decode('utf-8')
    if not zip_save_path == '' and os.path.isdir(zip_save_path):
        save_wizard_backup(zip_save_path)
    else:
        dialog.ok('ACHTUNG !','Addon Settings : Backup Sicherungspfad ?')
        xbmc.executebuiltin('Addon.OpenSettings('+addon.getAddonInfo('id').decode('utf-8')+')')
        sys.exit(0)
if mode==2:
    xbmc.executebuiltin('Addon.OpenSettings('+addon.getAddonInfo('id').decode('utf-8')+')')
    sys.exit(0)
if mode==5:
    fresh_start()
    sys.exit(0)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
xbmc.executebuiltin('Container.SetViewMode(500)')