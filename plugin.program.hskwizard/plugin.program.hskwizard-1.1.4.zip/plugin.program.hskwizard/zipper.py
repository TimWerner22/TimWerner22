#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,zipfile
def ZipDir(dir,zip_file,dp=None):
    try:
        zip = zipfile.ZipFile(zip_file,'w',compression=zipfile.ZIP_DEFLATED)
        root_len = len(os.path.abspath(dir))
        filesCount =float(0)
        filesCount += float(len(list(os.walk(dir,topdown=False,onerror=None,followlinks=False))))
        count  = 0
        for root, dirs, files in os.walk(dir,topdown=False,onerror=None,followlinks=False):
            archive_root = os.path.abspath(root)[root_len:]
            for f in files:
                fullpath = os.path.join(root,f)
                archive_name = os.path.join(archive_root,f)
                zip.write(fullpath, archive_name, zipfile.ZIP_DEFLATED)
            count += 1
            update = count / filesCount * 100
            dp.update(int(update))
            if dp.iscanceled():
                dp.close()
                sys.exit(1)
        zip.close()
    except Exception,e:
        xbmcgui.Dialog().ok('ERROR !',str(e))
        sys.exit(1)