#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys
def clean_data(clear_dir_path,dp=None):
    try:
        skin = xbmc.getSkinDir().decode("utf-8")
        skin_addon = xbmcaddon.Addon(id=skin)
        skin_label = skin_addon.getAddonInfo('id').decode("utf-8")
        save_addon1 ='plugin.program.hskwizard'
        save_addon2 = skin_label
        save_addon3 ='Addons26.db'
        save_addon4 ='Addons27.db'
        save_addon5 ='Textures13.db'
        save_addon6 ='commoncache.db'	
        save_addon7 ='metadata.album.universal'
        save_addon8 ='metadata.artists.universal'
        save_addon9 ='metadata.common.musicbrainz.org'
        save_addon10 ='metadata.common.imdb.com'
        xbmc.executebuiltin('Action(Stop)')
        filesCount =float(0)
        filesCount += float(len(list(os.walk(clear_dir_path,topdown=False,onerror=None,followlinks=False))))
        count = 0
        for pathentry in os.walk(clear_dir_path,topdown=False,onerror=None,followlinks=False):
            for dir in pathentry[1]:
                path = os.path.join(pathentry[0],dir)
                if not save_addon1 in path and not save_addon2 in path and not save_addon3 in path and not save_addon4 in path and not save_addon5 in path and not save_addon6 in path and not save_addon7 in path and not save_addon8 in path and not save_addon9 in path and not save_addon10 in path:
                    if os.path.islink(path):
                        try:
                            os.unlink(path)
                        except:
                            pass
                    else:
                        try:
                            os.rmdir(path)
                        except:
                            pass
            for file in pathentry[2]:
                path = os.path.join(pathentry[0],file)
                if not save_addon1 in path and not save_addon2 in path and not save_addon3 in path and not save_addon4 in path and not save_addon5 in path and not save_addon6 in path and not save_addon7 in path and not save_addon8 in path and not save_addon9 in path and not save_addon10 in path:			
                    try:
                        os.unlink(path)
                    except:
                        pass
            count += 1
            update = count / filesCount * 100
            dp.update(int(update))
            if dp.iscanceled():
                dp.close()
                sys.exit(1)
        dp.close()
    except Exception,e:
        xbmcgui.Dialog().ok('ERROR !',str(e))
        sys.exit(1)