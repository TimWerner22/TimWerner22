#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcgui,sys,zipfile
def extractZip(_in,_out,dp=None):
    zip    = zipfile.ZipFile(_in,'r')
    nFiles = float(len(zip.infolist()))
    count  = 0
    try:
        for item in zip.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            try:
                if not 'plugin.program.hskwizard' in str(item.filename):
                    zip.extract(item, _out)
            except:
                pass	
            if dp.iscanceled():
                dp.close()
                sys.exit(1)
    except Exception,e:
        xbmcgui.Dialog().ok('ERROR !',str(e))
        sys.exit(1)