#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib2,xbmcgui,re

def read_content(url):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.29 Safari/537.36')
        response = urllib2.urlopen(req)
        res=response.read()
        response.close()
        return res
    except Exception,err:
        xbmcgui.Dialog().ok('Error !',str(err))
        sys.exit(0)

my_ip_data = ''
for match in enumerate(re.findall('Ihre aktuelle IP Adresse:(.+?)<|DNS Name:(.+?)<|Land:(.+?)<|Stadt:(.+?)<|Bundesland:(.+?)<|ngengrad:(.+?)<|Breitengrad:(.+?)<',read_content('http://www.meine-aktuelle-ip.de/'))):
    if match[1][0]:
        my_ip_data = 'Ihre aktuelle IP Adresse :' + match[1][0] +'\n'
    if match[1][1]:
        my_ip_data += 'DNS Name :' + match[1][1] +'\n'
    if match[1][2]:
        my_ip_data += 'Land :' + match[1][2] +'\n'
    if match[1][3]:
        my_ip_data += 'Stadt :' + match[1][3] +'\n'
    if match[1][4]:
        my_ip_data += 'Bundesland :' + match[1][4] +'\n'
    if match[1][5]:
       my_ip_data += 'Längengrad :' + match[1][5] +'\n'
    if match[1][6]:
        my_ip_data += 'Breitengrad :' + match[1][6] +'\n'

xbmcgui.Dialog().textviewer('MY EXTERN IP', my_ip_data )